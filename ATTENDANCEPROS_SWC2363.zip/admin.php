<?php
require_once 'config.php';

if (!isLoggedIn()) {
    echo "<script>alert('Please login first!'); window.location.href='index.php'</script>";
}

if (!isAdmin()) {
    echo "<script>alert('You do not have permission to access this page'); window.location.href='staff.php'</script>";
}

$active_section = 'attendanceReportSection';

if (isset($_GET['section'])) {
    $active_section = $_GET['section'];
    $_SESSION['active_section'] = $active_section;
} elseif (isset($_SESSION['active_section'])) {
    $active_section = $_SESSION['active_section'];
}

$user_id = getUserId();
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$admin = $stmt->get_result()->fetch_assoc();


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    
    $profile_picture = $admin['profile_picture'];
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/profile_pictures/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_ext = pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
        $file_name = "admin_{$user_id}_" . time() . ".$file_ext";
        $file_path = $upload_dir . $file_name;
        
        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $file_path)) {
            $profile_picture = $file_path;
            if ($admin['profile_picture'] && file_exists($admin['profile_picture'])) {
                unlink($admin['profile_picture']);
            }
        }
    }
    
    $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, profile_picture = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $full_name, $email, $phone, $profile_picture, $user_id);
    
    if ($stmt->execute()) {
        $_SESSION['full_name'] = $full_name;
        echo "<script>alert('Profile updated successfully!'); window.location.href='admin.php'</script>";
    } else {
        echo "<script>alert('Failed to update profile'); window.location.href='admin.php'</script>";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['add_employee'])) {
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
        $full_name = trim($_POST['full_name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $address = trim($_POST['address']);
        $date_joined = trim($_POST['date_joined']);
        $role = 'staff';
        
        $stmt = $conn->prepare("INSERT INTO users (username, password, full_name, email, phone, address, date_joined, role) 
                               VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssssss", $username, $password, $full_name, $email, $phone, $address, $date_joined, $role);
        
        if ($stmt->execute()) {
            echo "<script>alert('Employee added successfully'); window.location.href='admin.php'</script>";
        } else {
            echo "<script>alert('Failed to add employee!'); window.location.href='admin.php'</script>";
        }
    } elseif (isset($_POST['update_employee'])) {
        $employee_id = $_POST['employee_id'];
        $username = trim($_POST['username']);
        $full_name = trim($_POST['full_name']);
        $email = trim($_POST['email']);
        $phone = trim($_POST['phone']);
        $address = trim($_POST['address']);
        $date_joined = trim($_POST['date_joined']);
        
        if (!empty($_POST['password'])) {
            $password = trim($_POST['password']);
            $stmt = $conn->prepare("UPDATE users SET username = ?, password = ?, full_name = ?, email = ?, phone = ?, address = ?, date_joined = ? WHERE id = ?");
            $stmt->bind_param("sssssssi", $username, $password, $full_name, $email, $phone, $address, $date_joined, $employee_id);
        } else {
            $stmt = $conn->prepare("UPDATE users SET username = ?, full_name = ?, email = ?, phone = ?, address = ?, date_joined = ? WHERE id = ?");
            $stmt->bind_param("ssssssi", $username, $full_name, $email, $phone, $address, $date_joined, $employee_id);
        }
        
        if ($stmt->execute()) {
            echo "<script>alert('Employee updated successfully'); window.location.href='admin.php'</script>";
        } else {
            echo "<script>alert('Failed to update employee'); window.location.href='admin.php'</script>";
        }
    } elseif (isset($_POST['delete_employee'])) {
        $employee_id = $_POST['employee_id'];
        
        $stmt = $conn->prepare("DELETE FROM users WHERE id = ?");
        $stmt->bind_param("i", $employee_id);
        
        if ($stmt->execute()) {
            echo "<script>alert('Employee deleted successfully'); window.location.href='admin.php'</script>";
        } else {
            echo "<script>alert('Failed to delete employee'); window.location.href='admin.php'</script>";
        }
    } elseif (isset($_POST['update_policy'])) {
        $policy = trim($_POST['policy']);
        
        $stmt = $conn->prepare("UPDATE policies SET content = ? WHERE id = 1");
        $stmt->bind_param("s", $policy);
        
        if ($stmt->execute()) {
            echo "<script>alert('Policy updated successfully'); window.location.href='admin.php'</script>";
        } else {
            echo "<script>alert('Failed to update policy'); window.location.href='admin.php'</script>";
        }
    }
}

$employees = $conn->query("SELECT id, username, full_name, email, phone, address, date_joined FROM users WHERE role = 'staff'")->fetch_all(MYSQLI_ASSOC);

$attendance_records = $conn->query("SELECT a.date, a.punch_in, a.punch_out, a.shift, a.status, u.full_name 
                                   FROM attendance a JOIN users u ON a.user_id = u.id 
                                   ORDER BY a.date DESC, a.punch_in DESC LIMIT 50")->fetch_all(MYSQLI_ASSOC);

$policy = $conn->query("SELECT content FROM policies WHERE id = 1")->fetch_assoc();
$policy_content = $policy ? $policy['content'] : '';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - AttendancePro</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    
    <style>
        /* General Styling */
        body {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f9;
            color: #333;
        }

        /* Header Styling */
        header {
            background-color: #003366;
            color: #fff;
            padding: 15px 20px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 28px;
            font-weight: 600;
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .header-actions a {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            transition: color 0.3s ease;
        }

        .header-actions a:hover {
            color: #ffcc00;
        }

        .profile-dropdown {
            position: relative;
            display: inline-block;
        }

        .profile-icon {
            cursor: pointer;
            font-size: 28px;
        }

        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: #f9f9f9;
            min-width: 200px;
            box-shadow: 0px 8px 16px 0px rgba(0, 0, 0, 0.2);
            z-index: 1;
            border-radius: 5px;
            overflow: hidden;
        }

        .dropdown-content a {
            color: #333;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            transition: background 0.3s ease;
        }

        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }

        .profile-dropdown:hover .dropdown-content {
            display: block;
        }

        .profile-info {
            padding: 12px 16px;
            border-bottom: 1px solid #ddd;
            display: flex;
            align-items: center;
        }

        .profile-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            margin-right: 10px;
        }

        .profile-info span {
            font-weight: 600;
            color: #333;
        }

        /* Main Content Styling */
        .dashboard {
            padding: 20px;
        }

        .hidden {
            display: none;
        }

        .welcome-section {
            margin-bottom: 20px;
        }

        .welcome-section h2 {
            font-size: 24px;
            margin-bottom: 10px;
        }

        .report-section, .settings-section {
            background: #fff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .filters {
            margin-bottom: 20px;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            align-items: center;
        }

        .filters input, .filters select {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }

        .btn-primary, .btn-secondary {
            padding: 12px 20px;
            border: none;
            border-radius: 5px;
            font-size: 1rem;
            cursor: pointer;
            transition: background 0.3s ease;
            margin: 5px;
        }

        .btn-primary {
            background-color: #003366;
            color: #fff;
        }

        .btn-primary:hover {
            background-color: #0056b3;
        }

        .btn-secondary {
            background-color: #6c757d;
            color: #fff;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 10px;
            text-align: left;
        }

        th {
            background-color: #003366;
            color: #fff;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #f1f1f1;
        }

        .settings-content {
            background: #f9f9f9;
            padding: 20px;
            border-radius: 10px;
            margin-top: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }

        form {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }

        form label {
            font-weight: bold;
        }

        form input, form select, form textarea {
            padding: 10px;
            border: 1px solid #ddd;
            border-radius: 5px;
            font-size: 1rem;
        }

        form textarea {
            resize: vertical;
            height: 100px;
        }

        /* Edit Profile Section */
        .edit-profile-section {
            max-width: 500px;
            margin: 0 auto;
            padding: 30px;
            background: #fff;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1);
            overflow: hidden;
        }

        .profile-header {
            text-align: center;
            margin-bottom: 20px;
        }

        .profile-header h2 {
            font-size: 24px;
            font-weight: 600;
            color: #003366;
        }

        .profile-picture-upload {
            text-align: center;
            margin-bottom: 20px;
        }

        .profile-picture-container {
            position: relative;
            display: inline-block;
        }

        .profile-picture-container img {
            width: 100px;
            height: 100px;
            border-radius: 50%;
            border: 3px solid #003366;
            transition: transform 0.3s ease;
        }

        .profile-picture-container img:hover {
            transform: scale(1.05);
        }

        .upload-label {
            position: absolute;
            bottom: 0;
            right: 0;
            background: #003366;
            color: #fff;
            border-radius: 50%;
            padding: 8px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .upload-label:hover {
            background: #002244;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .input-container {
            position: relative;
            margin-bottom: 20px;
        }

        .input-container i {
            position: absolute;
            left: 10px;
            top: 50%;
            transform: translateY(-50%);
            color: #666;
        }

        .input-container input {
            width: 100%;
            padding: 10px 10px 10px 40px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s ease;
            box-sizing: border-box;
        }

        .input-container input:focus {
            outline: none;
            border-color: #003366;
        }

        .input-container label {
            position: absolute;
            left: 40px;
            top: 50%;
            transform: translateY(-50%);
            background: #fff;
            padding: 0 5px;
            font-size: 14px;
            color: #666;
            transition: all 0.3s ease;
            pointer-events: none;
        }

        .input-container input:focus + label,
        .input-container input:not(:placeholder-shown) + label {
            top: 0;
            font-size: 12px;
            color: #003366;
        }

        .form-actions {
            display: flex;
            justify-content: space-between;
            gap: 10px;
        }

        .save-btn, .cancel-btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            cursor: pointer;
            transition: background 0.3s ease;
            width: 48%;
            box-sizing: border-box;
        }

        .save-btn {
            background-color: #003366;
            color: white;
        }

        .save-btn:hover {
            background-color: #002244;
        }

        .cancel-btn {
            background-color: #f5f5f5;
            color: #333;
        }

        .cancel-btn:hover {
            background-color: #ddd;
        }

        #successMessage {
            display: none;
            color: green;
            text-align: center;
            margin-top: 10px;
        }

        /* Employee Management Styles */
        .employee-actions {
            display: flex;
            justify-content: space-between;
            margin-bottom: 20px;
        }

        .employee-form {
            background: #fff;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            margin-bottom: 20px;
        }

        .form-row {
            display: flex;
            gap: 15px;
            margin-bottom: 15px;
        }

        .form-col {
            flex: 1;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
            justify-content: flex-end;
        }

        .edit-btn, .delete-btn {
            padding: 5px 10px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            transition: background 0.3s ease;
        }

        .edit-btn {
            background-color: #ffc107;
            color: #000;
        }

        .edit-btn:hover {
            background-color: #e0a800;
        }

        .delete-btn {
            background-color: #dc3545;
            color: #fff;
        }

        .delete-btn:hover {
            background-color: #c82333;
        }

        /* Responsive adjustments */
        @media (max-width: 768px) {
            .header-actions {
                gap: 10px;
            }
            
            .form-row {
                flex-direction: column;
                gap: 0;
            }
            
            .filters {
                flex-direction: column;
                align-items: flex-start;
            }

            .action-buttons {
                display: flex;
                justify-content: flex-end;
                gap: 10px;
                margin-top: 20px;
            }
        }

        .message {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            text-align: center;
        }
        
        .message.success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .message.error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>

<header>
        <div class="logo">AttendancePro</div>
        <div class="header-actions">
    <a href="?section=attendanceReportSection" id="attendanceReportBtn"><i class="fas fa-file-alt"></i> Attendance Report</a>
    <a href="?section=manageEmployeesSection" id="manageEmployeesBtn"><i class="fas fa-users-cog"></i> Manage Employees</a>
    <a href="?section=attendancePoliciesSection" id="attendancePoliciesBtn"><i class="fas fa-clipboard-list"></i> Attendance Policies</a>
    <div class="profile-dropdown">
        <i class="fas fa-user-circle profile-icon"></i>
        <div class="dropdown-content">
            <div class="profile-info">
                <img src="<?php echo $admin['profile_picture'] ? htmlspecialchars($admin['profile_picture']) : 'uploads/profile_pictures/default.avif'; ?>" alt="Profile Picture">
                <span id="dropdownProfileName"><?php echo htmlspecialchars($admin['full_name']); ?></span>
            </div>
            <a href="?section=editProfileSection" id="editProfileBtn"><i class="fas fa-user-edit"></i> Edit Profile</a>
            <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
        </div>
    </div>
</div>
    </header>



    <main class="dashboard">
        <?php echo displayMessage(); ?>
        
        <!-- Welcome Section -->
        <div class="welcome-section">
            <h2>Welcome, Admin</h2>
        </div>

        <!-- Edit Profile Section -->
        <div class="edit-profile-section hidden" id="editProfileSection">
            <div class="profile-header">
                <h2>Edit Profile</h2>
            </div>
            <form method="POST" action="" enctype="multipart/form-data">
                <div class="profile-picture-upload">
                    <div class="profile-picture-container">
                        <img src="<?php echo $admin['profile_picture'] ? htmlspecialchars($admin['profile_picture']) : 'uploads/profile_pictures/default.avif'; ?>" alt="Profile Picture" id="profilePicture">
                        <label for="profilePictureInput" class="upload-label">
                            <i class="fas fa-camera"></i>
                        </label>
                        <input type="file" id="profilePictureInput" name="profile_picture" accept="image/*" style="display: none;">
                    </div>
                </div>
                <div class="form-group">
                    <div class="input-container">
                        <i class="fas fa-user"></i>
                        <input type="text" id="fullName" name="full_name" placeholder=" " value="<?php echo htmlspecialchars($admin['full_name']); ?>" required>
                        <label for="fullName">Full Name</label>
                    </div>
                    <div class="input-container">
                        <i class="fas fa-envelope"></i>
                        <input type="email" id="email" name="email" placeholder=" " value="<?php echo htmlspecialchars($admin['email']); ?>" required>
                        <label for="email">Email</label>
                    </div>
                    <div class="input-container">
                        <i class="fas fa-phone"></i>
                        <input type="text" id="phone" name="phone" placeholder=" " value="<?php echo htmlspecialchars($admin['phone']); ?>" required>
                        <label for="phone">Phone Number</label>
                    </div>
                </div>
                <div class="form-actions">
                    <button type="submit" name="update_profile" class="save-btn">Save Changes</button>
                    <button type="button" class="cancel-btn" id="cancelEditProfileBtn">Cancel</button>
                </div>
            </form>
            <div id="successMessage">Changes saved successfully!</div>
        </div>

        <!-- Attendance Report Section -->
        <div class="report-section" id="attendanceReportSection">
            <h3>Attendance Reports</h3>
            <div class="filters">
                <form id="attendanceSearchForm" style="display: flex; gap: 10px; align-items: center; width: 100%;">
                    <input type="text" id="attendanceSearchInput" placeholder="Search by username" style="flex: 1;">
                    <button type="submit" class="btn-primary">Search</button>
                </form>
            </div>
            <table id="attendanceReportTable">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Employee</th>
                        <th>Punch In</th>
                        <th>Punch Out</th>
                        <th>Shift</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($attendance_records as $record): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($record['date']); ?></td>
                        <td><?php echo htmlspecialchars($record['full_name']); ?></td>
                        <td><?php echo htmlspecialchars(date('h:i A', strtotime($record['punch_in']))); ?></td>
                        <td><?php echo $record['punch_out'] ? htmlspecialchars(date('h:i A', strtotime($record['punch_out']))) : '-'; ?></td>
                        <td><?php echo htmlspecialchars(ucfirst($record['shift'])); ?></td>
                        <td><?php echo $record['status'] === 'late' ? 'Late' : 'On Time'; ?></td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Manage Employees Section -->
        <div id="manageEmployeesSection" class="settings-content hidden">
            <div class="employee-actions">
                <h4>Manage Employees</h4>
                <button id="addEmployeeBtn" class="btn-primary">Add New Employee</button>
            </div>
            
            <div class="employee-form hidden" id="employeeFormContainer">
                <h5 id="employeeFormTitle">Add New Employee</h5>
                <form id="employeeForm" method="POST" action="">
                    <input type="hidden" id="employeeId" name="employee_id">
                    <div class="form-row">
                        <div class="form-col">
                            <label for="employeeUsername">Username*</label>
                            <input type="text" id="employeeUsername" name="username" required>
                        </div>
                        <div class="form-col">
                            <label for="employeePassword">Password*</label>
                            <input type="password" id="employeePassword" name="password">
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="employeeFullName">Full Name*</label>
                            <input type="text" id="employeeFullName" name="full_name" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="employeeEmail">Email*</label>
                            <input type="email" id="employeeEmail" name="email" required>
                        </div>
                        <div class="form-col">
                            <label for="employeePhone">Phone*</label>
                            <input type="text" id="employeePhone" name="phone" required>
                        </div>
                    </div>
                    <div class="form-row">
                        <div class="form-col">
                            <label for="employeeDateJoined">Date Joined*</label>
                            <input type="date" id="employeeDateJoined" name="date_joined" required>
                        </div>
                        <div class="form-col">
                            <label for="employeeAddress">Address*</label>
                            <input type="text" id="employeeAddress" name="address" required>
                        </div>
                    </div>
                    <div class="action-buttons">
                        <button type="button" id="cancelEmployeeBtn" class="btn-secondary">Cancel</button>
                        <button type="submit" id="saveEmployeeBtn" name="add_employee" class="btn-primary">Save</button>
                    </div>
                </form>
            </div>
            
            <table id="employeeTable">
                <thead>
                    <tr>
                        <th>Full Name</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Date Joined</th>
                        <th>Address</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($employees as $employee): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($employee['full_name']); ?></td>
                        <td><?php echo htmlspecialchars($employee['email']); ?></td>
                        <td><?php echo htmlspecialchars($employee['phone']); ?></td>
                        <td><?php echo htmlspecialchars($employee['date_joined']); ?></td>
                        <td><?php echo htmlspecialchars($employee['address']); ?></td>
                        <td>
                            <button class="edit-btn" data-id="<?php echo $employee['id']; ?>" 
                                    data-username="<?php echo htmlspecialchars($employee['username']); ?>" 
                                    data-full_name="<?php echo htmlspecialchars($employee['full_name']); ?>" 
                                    data-email="<?php echo htmlspecialchars($employee['email']); ?>" 
                                    data-phone="<?php echo htmlspecialchars($employee['phone']); ?>" 
                                    data-date_joined="<?php echo htmlspecialchars($employee['date_joined']); ?>" 
                                    data-address="<?php echo htmlspecialchars($employee['address']); ?>">Edit</button>
                            <form method="POST" action="" style="display: inline;">
                                <input type="hidden" name="employee_id" value="<?php echo $employee['id']; ?>">
                                <button type="submit" name="delete_employee" class="delete-btn">Delete</button>
                            </form>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>

        <!-- Attendance Policies Section -->
        <div id="attendancePoliciesSection" class="settings-content hidden">
            <h4>Attendance Policies</h4>
            <form id="policyForm" method="POST" action="">
                <label for="policy">Policy Details:</label>
                <textarea id="policy" name="policy" required><?php echo htmlspecialchars($policy_content); ?></textarea>
                <button type="submit" name="update_policy" class="btn-primary">Save Policy</button>
            </form>
        </div>
    </main>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        const activeSection = "<?php echo $active_section; ?>";
        
        if (activeSection) {
            toggleSection(activeSection);
        }
    });

    function toggleSection(sectionId) {
        const sections = ["attendanceReportSection", "manageEmployeesSection", "attendancePoliciesSection", "editProfileSection"];
        sections.forEach(id => {
            const section = document.getElementById(id);
            if (section) {
                section.classList.toggle("hidden", id !== sectionId);
            }
        });
        
        if (sectionId) {
            history.replaceState(null, null, "?section=" + sectionId);
        }
    }

    document.getElementById("manageEmployeesBtn").addEventListener("click", (e) => {
        e.preventDefault();
        toggleSection("manageEmployeesSection");
    });

    document.getElementById("attendanceReportBtn").addEventListener("click", (e) => {
        e.preventDefault();
        toggleSection("attendanceReportSection");
    });

    document.getElementById("attendancePoliciesBtn").addEventListener("click", (e) => {
        e.preventDefault();
        toggleSection("attendancePoliciesSection");
    });

    document.getElementById("editProfileBtn").addEventListener("click", (e) => {
        e.preventDefault();
        toggleSection("editProfileSection");
    });

    document.getElementById("cancelEditProfileBtn").addEventListener("click", (e) => {
        e.preventDefault();
        toggleSection("attendanceReportSection");
    });

        document.getElementById('addEmployeeBtn').addEventListener('click', function() {
            document.getElementById('employeeFormContainer').classList.remove('hidden');
            document.getElementById('employeeFormTitle').textContent = 'Add New Employee';
            document.getElementById('employeeForm').reset();
            document.getElementById('employeeId').value = '';
            document.getElementById('saveEmployeeBtn').name = 'add_employee';
            document.getElementById('saveEmployeeBtn').textContent = 'Save';
        });

        document.getElementById('cancelEmployeeBtn').addEventListener('click', function() {
            document.getElementById('employeeFormContainer').classList.add('hidden');
        });

        document.querySelectorAll('.edit-btn').forEach(btn => {
            btn.addEventListener('click', function() {
                document.getElementById('employeeFormContainer').classList.remove('hidden');
                document.getElementById('employeeFormTitle').textContent = 'Edit Employee';
                
                document.getElementById('employeeId').value = this.dataset.id;
                document.getElementById('employeeUsername').value = this.dataset.username;
                document.getElementById('employeeFullName').value = this.dataset.full_name;
                document.getElementById('employeeEmail').value = this.dataset.email;
                document.getElementById('employeePhone').value = this.dataset.phone;
                document.getElementById('employeeDateJoined').value = this.dataset.date_joined;
                document.getElementById('employeeAddress').value = this.dataset.address;
                
                document.getElementById('saveEmployeeBtn').name = 'update_employee';
                document.getElementById('saveEmployeeBtn').textContent = 'Update';
                
                document.getElementById('manageEmployeesSection').scrollIntoView();
            });
        });

        document.getElementById('attendanceSearchForm').addEventListener('submit', function(e) {
            e.preventDefault();
            const searchTerm = document.getElementById('attendanceSearchInput').value.toLowerCase();
            const rows = document.querySelectorAll('#attendanceReportTable tbody tr');
            
            rows.forEach(row => {
                const employeeName = row.cells[1].textContent.toLowerCase();
                if (employeeName.includes(searchTerm)) {
                    row.style.display = '';
                } else {
                    row.style.display = 'none';
                }
            });
        });

        document.getElementById('profilePictureInput').addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('profilePicture').src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>