-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost:8889
-- Generation Time: Mar 28, 2025 at 07:09 PM
-- Server version: 5.7.34
-- PHP Version: 8.0.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `attendance_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `attendance`
--

CREATE TABLE `attendance` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `punch_in` time NOT NULL,
  `punch_out` time DEFAULT NULL,
  `shift` enum('morning','afternoon','closing') NOT NULL,
  `status` enum('on_time','late') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `attendance`
--

INSERT INTO `attendance` (`id`, `user_id`, `date`, `punch_in`, `punch_out`, `shift`, `status`) VALUES
(1, 2, '2025-03-19', '10:05:12', '15:00:21', 'morning', 'late'),
(2, 2, '2025-03-20', '13:00:25', '19:45:03', 'afternoon', 'on_time'),
(3, 2, '2025-03-22', '15:55:25', '22:35:32', 'closing', 'on_time'),
(4, 2, '2025-03-28', '18:34:57', '18:35:24', 'morning', 'late'),
(5, 2, '2025-03-28', '18:35:30', '18:35:30', 'closing', 'late'),
(6, 4, '2025-03-28', '19:01:42', '19:01:45', 'morning', 'late'),
(7, 4, '2025-03-28', '19:01:49', '19:01:51', 'afternoon', 'late'),
(8, 4, '2025-03-28', '19:01:54', '19:01:55', 'closing', 'late'),
(9, 2, '2025-03-28', '19:03:05', NULL, 'afternoon', 'late');

-- --------------------------------------------------------

--
-- Table structure for table `policies`
--

CREATE TABLE `policies` (
  `id` int(11) NOT NULL,
  `title` varchar(100) NOT NULL,
  `content` text NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `policies`
--

INSERT INTO `policies` (`id`, `title`, `content`, `created_at`, `updated_at`) VALUES
(1, 'Attendance Policy', '1. Employees must punch in and out for each shift.\r\n2. Morning shift: 9:30 AM - 3:00 PM\r\n3. Afternoon shift: 1:00 PM - 7:30 PM\r\n4. Closing shift: 4:00 PM - 10:30 PM\r\n5. Late arrivals will be marked accordingly.zzzz', '2025-03-28 18:09:41', '2025-03-28 18:51:26');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `address` text,
  `role` enum('admin','staff') NOT NULL,
  `date_joined` date NOT NULL,
  `profile_picture` text,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `email`, `phone`, `address`, `role`, `date_joined`, `profile_picture`, `created_at`) VALUES
(1, 'admin', 'admin123', 'Admin Alex222222', 'alexadmin@gmail.com', '60156441258', NULL, 'admin', '2025-03-29', 'uploads/profile_pictures/admin_1_1743186745.png', '2025-03-28 18:09:41'),
(2, 'syasha', 'staff123', 'NURSYASHA AMIRAzz', 'nsyasha000@gmail.com', '012345678911', 'zzz', 'staff', '2023-01-15', 'uploads/profile_pictures/user_2_1743186959.png', '2025-03-28 18:09:41'),
(4, 'amir', '12345', 'amir', 'amir@gmail.com', '0192929292', 'none', 'staff', '2025-03-29', 'uploads/profile_pictures/user_4_1743188499.png', '2025-03-28 18:59:53');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `attendance`
--
ALTER TABLE `attendance`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `policies`
--
ALTER TABLE `policies`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `attendance`
--
ALTER TABLE `attendance`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `policies`
--
ALTER TABLE `policies`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `attendance`
--
ALTER TABLE `attendance`
  ADD CONSTRAINT `attendance_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
