<?php
require_once 'config.php';

if (!isLoggedIn()) {
    echo "<script>alert('Please login first'); window.location.href='index.php'</script>";
}

if (isAdmin()) {
    echo "<script>alert('Admins cannot access staff dashboard'); window.location.href='admin.php'</script>";
}


$user_id = getUserId();
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_profile'])) {
    $full_name = trim($_POST['full_name']);
    $email = trim($_POST['email']);
    $phone = trim($_POST['phone']);
    
    $profile_picture = $user['profile_picture'];
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $upload_dir = 'uploads/profile_pictures/';
        if (!file_exists($upload_dir)) {
            mkdir($upload_dir, 0777, true);
        }
        
        $file_ext = pathinfo($_FILES['profile_picture']['name'], PATHINFO_EXTENSION);
        $file_name = "user_{$user_id}_" . time() . ".$file_ext";
        $file_path = $upload_dir . $file_name;
        
        if (move_uploaded_file($_FILES['profile_picture']['tmp_name'], $file_path)) {
            $profile_picture = $file_path;
            if ($user['profile_picture'] && file_exists($user['profile_picture'])) {
                unlink($user['profile_picture']);
            }
        }
    }
    
    $stmt = $conn->prepare("UPDATE users SET full_name = ?, email = ?, phone = ?, profile_picture = ? WHERE id = ?");
    $stmt->bind_param("ssssi", $full_name, $email, $phone, $profile_picture, $user_id);
    
    if ($stmt->execute()) {
        $_SESSION['full_name'] = $full_name;
        echo "<script>alert('Profile updated successfully'); window.location.href='staff.php'</script>";
    } else {
        echo "<script>alert('Failed to update profile'); window.location.href='staff.php'</script>";
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['punch_in'])) {
        $shift = $_POST['shift'];
        $current_time = date('H:i:s');
        $current_date = date('Y-m-d');
        
        $stmt = $conn->prepare("SELECT id FROM attendance WHERE user_id = ? AND date = ? AND punch_out IS NULL");
        $stmt->bind_param("is", $user_id, $current_date);
        $stmt->execute();
        
        if ($stmt->get_result()->num_rows > 0) {
            $error = "You have already punched in today";
        } else {
            $status = 'on_time';
            $shift_times = [
                'morning' => '09:30:00',
                'afternoon' => '13:00:00',
                'closing' => '16:00:00'
            ];
            
            if ($current_time > $shift_times[$shift]) {
                $status = 'late';
            }
            
            $stmt = $conn->prepare("INSERT INTO attendance (user_id, date, punch_in, shift, status) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("issss", $user_id, $current_date, $current_time, $shift, $status);
            
            if ($stmt->execute()) {
                echo "<script>alert('Punched in successfully'); window.location.href='staff.php'</script>";
            } else {
                echo "<script>alert('Failed to punch in'); window.location.href='staff.php'</script>";
            }
        }
    } elseif (isset($_POST['punch_out'])) {
        $current_time = date('H:i:s');
        $current_date = date('Y-m-d');
        
        $stmt = $conn->prepare("SELECT id FROM attendance WHERE user_id = ? AND date = ? AND punch_out IS NULL");
        $stmt->bind_param("is", $user_id, $current_date);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows === 1) {
            $attendance_id = $result->fetch_assoc()['id'];
            
            $stmt = $conn->prepare("UPDATE attendance SET punch_out = ? WHERE id = ?");
            $stmt->bind_param("si", $current_time, $attendance_id);
            
            if ($stmt->execute()) {
                echo "<script>alert('Punched out successfully'); window.location.href='staff.php'</script>";
            } else {
                echo "<script>alert('Failed to punch out'); window.location.href='staff.php'</script>";
            }
        } else {
            echo "<script>alert('No active punch in found'); window.location.href='staff.php'</script>";
        }
    }
}

$punched_in = false;
$current_date = date('Y-m-d');
$stmt = $conn->prepare("SELECT id, punch_in, shift FROM attendance WHERE user_id = ? AND date = ? AND punch_out IS NULL");
$stmt->bind_param("is", $user_id, $current_date);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 1) {
    $punched_in = true;
    $attendance = $result->fetch_assoc();
}

$history_stmt = $conn->prepare("SELECT date, punch_in, punch_out, shift, status FROM attendance 
                               WHERE user_id = ? ORDER BY date DESC, punch_in DESC LIMIT 10");
$history_stmt->bind_param("i", $user_id);
$history_stmt->execute();
$history = $history_stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$recent_stmt = $conn->prepare("SELECT date, punch_in, punch_out, shift, status FROM attendance 
                              WHERE user_id = ? ORDER BY date DESC, punch_in DESC LIMIT 5");
$recent_stmt->bind_param("i", $user_id);
$recent_stmt->execute();
$recent_attendance = $recent_stmt->get_result()->fetch_all(MYSQLI_ASSOC);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Staff Dashboard - AttendancePro</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        body {
            font-family: 'Poppins', sans-serif; /* Use Poppins font */
            margin: 0;
            padding: 0;
            background-color: #f4f4f9; /* Light gray background */
            color: #333; /* Dark gray text color */
        }
        
        /* Header styling */
        header {
            background-color: #003366; /* Dark blue background */
            color: #fff; /* White text */
            padding: 15px 20px; /* Padding inside the header */
            display: flex;
            justify-content: space-between; /* Space between logo and profile dropdown */
            align-items: center; /* Center items vertically */
        }
        
        /* Logo styling */
        .logo {
            font-size: 28px;
            font-weight: 600; /* Bold text */
        }

        .header-actions {
            display: flex;
            align-items: center;
            gap: 20px;
        }

        .header-actions a {
            color: #fff;
            text-decoration: none;
            font-size: 16px;
            transition: color 0.3s ease;
        }

        .header-actions a:hover {
            color: #ffcc00;
        }
        
        /* Profile dropdown styling */
        .profile-dropdown {
            position: relative; /* Position relative for dropdown */
            display: inline-block;
        }

        /* Profile icon styling */
        .profile-icon {
            cursor: pointer; /* Change cursor to pointer on hover */
            font-size: 28px; /* Icon size */
        }

        /* Dropdown content (hidden by default) */
        .dropdown-content {
            display: none; /* Hidden by default */
            position: absolute; /* Position absolute for dropdown */
            right: 0; /* Align to the right */
            background-color: #f9f9f9; /* Light gray background */
            min-width: 200px; /* Minimum width */
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2); /* Shadow effect */
            z-index: 1; /* Ensure dropdown is on top */
            border-radius: 5px; /* Rounded corners */
            overflow: hidden; /* Hide overflow */
        }
        
        /* Dropdown links styling */
        .dropdown-content a {
            color: #333; /* Dark gray text */
            padding: 12px 16px; /* Padding inside links */
            text-decoration: none; /* Remove underline */
            display: block; /* Display as block */
            transition: background 0.3s ease; /* Smooth background transition */
        }
        
        /* Hover effect for dropdown links */
        .dropdown-content a:hover {
            background-color: #f1f1f1; /* Light gray background on hover */
        }

        /* Show dropdown on hover */
        .profile-dropdown:hover .dropdown-content {
            display: block; /* Show dropdown */
        }

        /* Profile info section inside dropdown */
        .profile-info {
            padding: 12px 16px; /* Padding inside profile info */
            border-bottom: 1px solid #ddd; /* Bottom border */
            display: flex;
            align-items: center; /* Center items vertically */
        }

        /* Profile picture styling */
        .profile-info img {
            width: 40px;
            height: 40px;
            border-radius: 50%; /* Circular image */
            margin-right: 10px; /* Space between image and text */
        }

        /* Profile name styling */
        .profile-info span {
            font-weight: 600; /* Bold text */
            color: #333; /* Dark gray text */
        }

        /* Main content sections */
        .dashboard {
            padding: 20px; /* Padding inside dashboard */
            text-align: center; /* Center align text */
        }
        
        /* Hide all sections by default */
        .section {
            display: none;
        }

        /* Show active section */
        .section.active {
            display: block;
        }

        /* Welcome section styling */
        .welcome-section {
            margin-bottom: 20px; /* Space below welcome section */
        }

        /* Welcome heading */
        .welcome-section h2 {
            font-size: 24px;
            margin-bottom: 10px; /* Space below heading */
        }

        /* Welcome paragraph */
        .welcome-section p {
            font-size: 16px;
            color: #666; /* Gray text */
        }

        /* Live clock styling */
        .clock {
            font-size: 28px;
            font-weight: bold; /* Bold text */
            margin-top: 10px; /* Space above clock */
        }

        /* Punch In/Out section styling */
        .punch-section {
            text-align: center; /* Center align text */
            margin-bottom: 20px; /* Space below punch section */
        }

        /* Punch status text */
        .punch-section p {
            font-weight: bold; /* Bold text */
            margin-top: 10px; /* Space above text */
        }

        /* Button styling */
        .btn-primary, .btn-secondary {
            padding: 12px 20px; /* Padding inside buttons */
            border: none; /* Remove border */
            border-radius: 5px; /* Rounded corners */
            font-size: 1rem; /* Font size */
            cursor: pointer; /* Pointer cursor */
            transition: background 0.3s ease; /* Smooth background transition */
            margin: 5px; /* Space between buttons */
        }

        /* Primary button (Punch In) */
        .btn-primary {
            background-color: #28a745; /* Green background */
            color: white; /* White text */
        }

        /* Primary button hover effect */
        .btn-primary:hover {
            background-color: #218838; /* Darker green on hover */
        }

        /* Secondary button (Punch Out) */
        .btn-secondary {
            background-color: #dc3545; /* Red background */
            color: white; /* White text */
        }

        /* Secondary button hover effect */
        .btn-secondary:hover {
            background-color: #c82333; /* Darker red on hover */
        }

        /* Shift select dropdown styling */
        #shiftSelect {
            padding: 10px; /* Padding inside dropdown */
            border-radius: 5px; /* Rounded corners */
            border: 1px solid #ddd; /* Light gray border */
            font-size: 16px; /* Font size */
            margin-bottom: 10px; /* Space below dropdown */
            width: 100%; /* Full width */
            max-width: 300px; /* Maximum width */
            text-align: center; /* Center align text */
        }

        /* Attendance table section styling */
        .attendance-section {
            background: #fff; /* White background */
            padding: 20px; /* Padding inside section */
            border-radius: 10px; /* Rounded corners */
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1); /* Shadow effect */
        }
        
        /* Table styling */
        .attendance-section table {
            width: 100%; /* Full width */
            border-collapse: collapse; /* Remove space between cells */
            margin-top: 20px; /* Space above table */
        }

        /* Table header and cell styling */
        .attendance-section th, .attendance-section td {
            padding: 10px; /* Padding inside cells */
            text-align: center; /* Center align text */
            border-bottom: 1px solid #ddd; /* Bottom border */
        }

        /* Table header styling */
        .attendance-section th {
            background-color: #003366; /* Dark blue background */
            color: white; /* White text */
        }

        /* Alternate row background color */
        .attendance-section tr:nth-child(even) {
            background-color: #f9f9f9; /* Light gray background */
        }

        /* Row hover effect */
        .attendance-section tr:hover {
            background-color: #f1f1f1; /* Lighter gray on hover */
        }

        /* Late status styling */
        .attendance-section .late {
            color: red; /* Red text */
            font-weight: bold; /* Bold text */
        }

        /* Off status styling */
        .attendance-section .off {
            color: #888; /* Gray text */
        }

        /* MC (Medical Certificate) status styling */
        .attendance-section .mc {
            color: #28a745; /* Green text */
        }

        /* AL (Annual Leave) status styling */
        .attendance-section .al {
            color: #ffc107; /* Yellow text */
        }
        
        /* Edit Profile Section */
        .edit-profile-section {
            max-width: 500px; /* Maximum width for the form */
            margin: 0 auto; /* Center the form */
            padding: 30px; /* Padding inside the form */
            background: #fff; /* White background */
            border-radius: 12px; /* Rounded corners */
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); /* Subtle shadow */
            overflow: hidden; /* Ensure nothing overflows */
        }
        
        /* Profile Header */
        .profile-header {
            text-align: center; /* Center align text */
            margin-bottom: 20px; /* Space below header */
        }
        
        .profile-header h2 {
            font-size: 24px; /* Font size */
            font-weight: 600; /* Bold text */
            color: #003366; /* Dark blue text */
        }
        
        /* Profile Picture Upload */
        .profile-picture-upload {
            text-align: center; /* Center align */
            margin-bottom: 20px; /* Space below upload section */
        }
        
        .profile-picture-container {
            position: relative; /* Position relative for upload label */
            display: inline-block;
        }
        
        .profile-picture-container img {
            width: 100px; /* Profile picture size */
            height: 100px;
            border-radius: 50%; /* Circular image */
            border: 3px solid #003366; /* Dark blue border */
            transition: transform 0.3s ease; /* Smooth hover effect */
        }
        
        .profile-picture-container img:hover {
            transform: scale(1.05); /* Slightly enlarge on hover */
        }
        
        .upload-label {
            position: absolute; /* Position absolute for label */
            bottom: 0;
            right: 0;
            background: #003366; /* Dark blue background */
            color: #fff; /* White text */
            border-radius: 50%; /* Circular label */
            padding: 8px; /* Padding inside label */
            cursor: pointer; /* Pointer cursor */
            transition: background 0.3s ease; /* Smooth background transition */
        }
        
        .upload-label:hover {
            background: #002244; /* Darker blue on hover */
        }
        
        /* Form Group */
        .form-group {
            margin-bottom: 20px; /* Space below form group */
        }
        
        /* Input Container */
        .input-container {
            position: relative; /* Position relative for icons and labels */
            margin-bottom: 20px; /* Space below input */
        }
        
        .input-container i {
            position: absolute; /* Position absolute for icons */
            left: 10px;
            top: 50%;
            transform: translateY(-50%); /* Center vertically */
            color: #666; /* Gray icon color */
        }
        
        .input-container input {
            width: 100%; /* Full width */
            padding: 10px 10px 10px 40px; /* Padding inside input */
            border: 1px solid #ddd; /* Light gray border */
            border-radius: 8px; /* Rounded corners */
            font-size: 14px; /* Font size */
            transition: border-color 0.3s ease; /* Smooth border transition */
            box-sizing: border-box; /* Ensure padding is included in width */
        }
        
        .input-container input:focus {
            outline: none; /* Remove default outline */
            border-color: #003366; /* Dark blue border on focus */
        }
        
        .input-container label {
            position: absolute; /* Position absolute for labels */
            left: 40px;
            top: 50%;
            transform: translateY(-50%); /* Center vertically */
            background: #fff; /* White background */
            padding: 0 5px; /* Padding inside label */
            font-size: 14px; /* Font size */
            color: #666; /* Gray text */
            transition: all 0.3s ease; /* Smooth transition */
            pointer-events: none; /* Disable pointer events */
        }
        
        /* Floating Label Effect */
        .input-container input:focus + label,
        .input-container input:not(:placeholder-shown) + label {
            top: 0; /* Move label up */
            font-size: 12px; /* Smaller font size */
            color: #003366; /* Dark blue text */
        }
        
        /* Form Actions (Buttons) */
        .form-actions {
            display: flex;
            justify-content: space-between; /* Space between buttons */
            gap: 10px; /* Space between buttons */
        }
        
        .save-btn, .cancel-btn {
            padding: 10px 20px; /* Padding inside buttons */
            border: none; /* Remove border */
            border-radius: 8px; /* Rounded corners */
            font-size: 14px; /* Font size */
            cursor: pointer; /* Pointer cursor */
            transition: background 0.3s ease; /* Smooth background transition */
            width: 48%; /* Equal width for buttons */
            box-sizing: border-box; /* Ensure padding is included in width */
        }
        
        .save-btn {
            background-color: #003366; /* Dark blue background */
            color: white; /* White text */
        }
        
        .save-btn:hover {
            background-color: #002244; /* Darker blue on hover */
        }
        
        .cancel-btn {
            background-color: #f5f5f5; /* Light gray background */
            color: #333; /* Dark gray text */
        }
        
        .cancel-btn:hover {
            background-color: #ddd; /* Lighter gray on hover */
        }
        
        /* Attendance History Section */
        .attendance-history-section {
            padding: 20px; /* Padding inside section */
            background: #fff; /* White background */
            border-radius: 12px; /* Rounded corners */
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.1); /* Shadow effect */
        }
        
        /* History Header */
        .history-header {
            display: flex;
            justify-content: space-between; /* Space between heading and search */
            align-items: center; /* Center items vertically */
            margin-bottom: 20px; /* Space below header */
        }
        
        .history-header h2 {
            font-size: 24px;
            font-weight: 600; /* Bold text */
            color: #003366; /* Dark blue text */
        }
        
        /* Search Filter */
        .search-filter {
            display: flex;
            gap: 10px; /* Space between search and filter */
        }
        
        /* Date Picker Input */
        .search-filter input[type="date"] {
            padding: 8px; /* Padding inside input */
            border: 1px solid #ddd; /* Light gray border */
            border-radius: 8px; /* Rounded corners */
            font-size: 14px; /* Font size */
            width: 200px; /* Fixed width for date picker */
        }
        
        /* Table Container */
        .table-container {
            overflow-x: auto; /* Enable horizontal scrolling */
        }
        
        /* Table Styling */
        table {
            width: 100%; /* Full width */
            border-collapse: collapse; /* Remove space between cells */
            margin-top: 20px; /* Space above table */
        }
        
        /* Table Header and Cell Styling */
        th, td {
            padding: 12px; /* Padding inside cells */
            text-align: center; /* Center align text */
            border-bottom: 1px solid #ddd; /* Bottom border */
        }
        
        /* Table Header Styling */
        th {
            background-color: #003366; /* Dark blue background */
            color: white; /* White text */
            position: sticky; /* Sticky header */
            top: 0; /* Stick to the top */
        }
        
        /* Alternate Row Background Color */
        tr:nth-child(even) {
            background-color: #f9f9f9; /* Light gray background */
        }
        
        /* Row Hover Effect */
        tr:hover {
            background-color: #f1f1f1; /* Lighter gray on hover */
        }
        
        /* Status Badge Styling */
        .status-badge {
            padding: 6px 12px; /* Padding inside badge */
            border-radius: 20px; /* Rounded corners */
            font-size: 12px; /* Font size */
            font-weight: 600; /* Bold text */
        }
        
        /* Late Status Badge */
        .status-badge.late {
            background-color: #ffebee; /* Light red background */
            color: #c62828; /* Dark red text */
        }
        
        /* On Time Status Badge */
        .status-badge.on-time {
            background-color: #e8f5e9; /* Light green background */
            color: #2e7d32; /* Dark green text */
        }
        
        /* Off Status Badge */
        .status-badge.off {
            background-color: #f5f5f5; /* Light gray background */
            color: #666; /* Gray text */
        }
        
        /* Back to Dashboard Button */
        #backToDashboardBtn {
            background-color: #003366; /* Dark blue background */
            color: white; /* White text */
            padding: 10px 20px; /* Padding inside button */
            border: none; /* Remove border */
            border-radius: 8px; /* Rounded corners */
            font-size: 14px; /* Font size */
            cursor: pointer; /* Pointer cursor */
            transition: background 0.3s ease; /* Smooth background transition */
            margin-top: 20px; /* Space above button */
        }
        
        #backToDashboardBtn:hover {
            background-color: #002244; /* Darker blue on hover */
        }

        #successMessage {
            display: none; /* Hidden by default */
            color: green; /* Success message color */
            text-align: center; /* Center-align text */
            margin-top: 10px; /* Add some spacing */
        }
        
        .message {
            padding: 10px;
            margin: 10px 0;
            border-radius: 5px;
            text-align: center;
        }
        
        .message.success {
            background-color: #d4edda;
            color: #155724;
        }
        
        .message.error {
            background-color: #f8d7da;
            color: #721c24;
        }
    </style>
</head>
<body>
    <header>
        <div class="logo">AttendancePro</div>
        <div class="header-actions">
        <a href="#" id="attendanceHistoryBtn"><i class="fas fa-history"></i> Attendance History</a>
        <div class="profile-dropdown">
            <i class="fas fa-user-circle profile-icon"></i>
            <div class="dropdown-content">
                <div class="profile-info">
                    <img src="<?php echo $user['profile_picture'] ? htmlspecialchars($user['profile_picture']) : 'uploads/profile_pictures/default.avif'; ?>" alt="Profile Picture">
                    <span id="dropdownProfileName"><?php echo htmlspecialchars($user['full_name']); ?></span>
                </div>
                <a href="#" id="editProfileBtn"><i class="fas fa-user-edit"></i> Edit Profile</a>
                <a href="logout.php"><i class="fas fa-sign-out-alt"></i> Logout</a>
            </div>
        </div>
    </header>

    <main class="dashboard">
        <?php echo displayMessage(); ?>
        
        <!-- Punch In/Out Section -->
        <div class="section active" id="punchSection">
            <div class="welcome-section">
                <h2>Welcome, <span id="staffName"><?php echo htmlspecialchars($user['full_name']); ?></span></h2>
                <p>Track your attendance.</p>
                <div class="clock" id="liveClock">00:00:00</div>
            </div>

            <div class="punch-section">
                <form method="POST" action="">
                    <label for="shiftSelect">Select Shift:</label>*
                    <select id="shiftSelect" name="shift" <?php echo $punched_in ? 'disabled' : ''; ?> required>
                        <option value="">--Select Shift--</option>
                        <option value="morning" <?php echo ($punched_in && $attendance['shift'] === 'morning') ? 'selected' : ''; ?>>Morning (9:30 AM - 3:00 PM)</option>
                        <option value="afternoon" <?php echo ($punched_in && $attendance['shift'] === 'afternoon') ? 'selected' : ''; ?>>Afternoon (1:00 PM - 7:30 PM)</option>
                        <option value="closing" <?php echo ($punched_in && $attendance['shift'] === 'closing') ? 'selected' : ''; ?>>Closing (4:00 PM - 10:30 PM)</option>
                    </select>
                    <?php if (!$punched_in): ?>
                        <button type="submit" name="punch_in" class="btn-primary"><i class="fas fa-play"></i> Punch In</button>
                    <?php else: ?>
                        <button type="submit" name="punch_out" class="btn-secondary"><i class="fas fa-stop"></i> Punch Out</button>
                    <?php endif; ?>
                    <p id="punchStatus">Status: <?php 
                        if ($punched_in) {
                            echo "Punched In (" . ucfirst($attendance['shift']) . ") at " . date('h:i A', strtotime($attendance['punch_in']));
                        } else {
                            echo "Ready to Punch In";
                        }
                    ?></p>
                </form>
            </div>

            <div class="attendance-section">
                <h3>Your Attendance Records</h3>
                <table>
                    <thead>
                        <tr>
                            <th>Date</th>
                            <th>Punch In</th>
                            <th>Punch Out</th>
                            <th>Shift</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($recent_attendance as $record): ?>
                        <tr>
                            <td><?php echo htmlspecialchars($record['date']); ?></td>
                            <td><?php echo htmlspecialchars(date('h:i:s A', strtotime($record['punch_in']))); ?></td>
                            <td><?php echo $record['punch_out'] ? htmlspecialchars(date('h:i:s A', strtotime($record['punch_out']))) : '-'; ?></td>
                            <td><?php echo htmlspecialchars(ucfirst($record['shift'])); ?></td>
                            <td class="<?php echo $record['status'] === 'late' ? 'late' : ''; ?>">
                                <?php echo $record['status'] === 'late' ? 'Late' : 'On Time'; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Edit Profile Section -->
        <div class="section" id="editProfileSection">
            <div class="edit-profile-section">
                <div class="profile-header">
                    <h2>Edit Profile</h2>
                </div>
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="profile-picture-upload">
                        <div class="profile-picture-container">
                            <img src="<?php echo $user['profile_picture'] ? htmlspecialchars($user['profile_picture']) : 'uploads/profile_pictures/default.avif'; ?>" alt="Profile Picture" id="profilePicture">
                            <label for="profilePictureInput" class="upload-label">
                                <i class="fas fa-camera"></i>
                            </label>
                            <input type="file" id="profilePictureInput" name="profile_picture" accept="image/*" style="display: none;">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="input-container">
                            <i class="fas fa-user"></i>
                            <input type="text" id="fullName" name="full_name" placeholder=" " value="<?php echo htmlspecialchars($user['full_name']); ?>" required>
                            <label for="fullName">Full Name</label>
                        </div>
                        <div class="input-container">
                            <i class="fas fa-envelope"></i>
                            <input type="email" id="email" name="email" placeholder=" " value="<?php echo htmlspecialchars($user['email']); ?>" required>
                            <label for="email">Email</label>
                        </div>
                        <div class="input-container">
                            <i class="fas fa-phone"></i>
                            <input type="text" id="phone" name="phone" placeholder=" " value="<?php echo htmlspecialchars($user['phone']); ?>" required>
                            <label for="phone">Phone Number</label>
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="update_profile" class="save-btn">Save Changes</button>
                        <button type="button" class="cancel-btn" id="cancelEditProfileBtn">Cancel</button>
                    </div>
                </form>
                <div id="successMessage">Changes saved successfully!</div>
            </div>
        </div>

        <!-- Attendance History Section -->
        <div class="section" id="attendanceHistorySection">
            <div class="attendance-history-section">
                <div class="history-header">
                    <h2>Attendance History</h2>
                    <div class="search-filter">
                        <!-- Date Picker for Search -->
                        <input type="date" id="searchDate" placeholder="Search by date...">
                    </div>
                </div>
                <div class="table-container">
                    <table>
                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Punch In</th>
                                <th>Punch Out</th>
                                <th>Shift</th>
                                <th>Status</th>
                            </tr>
                        </thead>
                        <tbody id="attendanceTableBody">
                            <?php foreach ($history as $record): ?>
                            <tr>
                                <td><?php echo htmlspecialchars($record['date']); ?></td>
                                <td><?php echo htmlspecialchars(date('h:i:s A', strtotime($record['punch_in']))); ?></td>
                                <td><?php echo $record['punch_out'] ? htmlspecialchars(date('h:i:s A', strtotime($record['punch_out']))) : '-'; ?></td>
                                <td><?php echo htmlspecialchars(ucfirst($record['shift'])); ?></td>
                                <td><span class="status-badge <?php echo $record['status'] === 'late' ? 'late' : 'on-time'; ?>">
                                    <?php echo $record['status'] === 'late' ? 'Late' : 'On Time'; ?>
                                </span></td>
                            </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <button class="btn-primary" id="backToDashboardBtn">Back to Dashboard</button>
            </div>
        </div>
    </main>

    <script>
        function updateClock() {
            const now = new Date();
            const hours = String(now.getHours()).padStart(2, '0');
            const minutes = String(now.getMinutes()).padStart(2, '0');
            const seconds = String(now.getSeconds()).padStart(2, '0');
            const liveClock = document.getElementById('liveClock');
            if (liveClock) {
                liveClock.textContent = `${hours}:${minutes}:${seconds}`;
            }
        }

        setInterval(updateClock, 1000);
        updateClock();

        const attendanceHistoryBtn = document.getElementById('attendanceHistoryBtn');
        const editProfileBtn = document.getElementById('editProfileBtn');
        const backToDashboardBtn = document.getElementById('backToDashboardBtn');
        const cancelEditProfileBtn = document.getElementById('cancelEditProfileBtn');

        const punchSection = document.getElementById('punchSection');
        const editProfileSection = document.getElementById('editProfileSection');
        const attendanceHistorySection = document.getElementById('attendanceHistorySection');

        function hideAllSections() {
            punchSection.classList.remove('active');
            editProfileSection.classList.remove('active');
            attendanceHistorySection.classList.remove('active');
        }

        function showSection(section) {
            hideAllSections();
            section.classList.add('active');
        }

        attendanceHistoryBtn.addEventListener('click', function (event) {
            event.preventDefault();
            showSection(attendanceHistorySection);
        });

        editProfileBtn.addEventListener('click', function (event) {
            event.preventDefault();
            showSection(editProfileSection);
        });

        cancelEditProfileBtn.addEventListener('click', function (event) {
            event.preventDefault();
            showSection(punchSection);
        });

        backToDashboardBtn.addEventListener('click', function (event) {
            event.preventDefault();
            showSection(punchSection);
        });

        showSection(punchSection);


        document.getElementById('searchDate').addEventListener('change', function () {
            const selectedDate = this.value;
            const tableBody = document.getElementById('attendanceTableBody');
            const rows = tableBody.getElementsByTagName('tr');

            for (let row of rows) {
                const dateCell = row.getElementsByTagName('td')[0];
                if (dateCell) {
                    const rowDate = dateCell.textContent;
                    if (selectedDate === '' || rowDate === selectedDate) {
                        row.style.display = '';
                    } else {
                        row.style.display = 'none';
                    }
                }
            }
        });

        document.getElementById('profilePictureInput').addEventListener('change', function(event) {
            const file = event.target.files[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    document.getElementById('profilePicture').src = e.target.result;
                };
                reader.readAsDataURL(file);
            }
        });
    </script>
</body>
</html>